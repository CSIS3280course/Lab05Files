<?php

//Config Variables
define("ACCOUNTS_FILE","data/accounts.csv");
define("NEWACCOUNTS_FILE","data/new_accounts.csv");

//Var for todolist
define("FILE_NAME", "data/todolist.txt");

?>
